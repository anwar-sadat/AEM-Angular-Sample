
var APP_DETAILS={
    rootPath:"",
    rootPageName:""

};