app.factory('AmwayService', function ($http, $q) {
	return {		
		getEmployeeDetails : function(token){			
            return $http.get('http://localhost:8080/AmwayTest/api/employees/getemployees?access_token='+token)
				.then(function(response){
					if (typeof response.data === 'object') {
                            return response.data;
                        } else {
                            // invalid response
                            return $q.reject(response.data);
                        }
					
				},				
				function(response){					
					return $q.reject(response.data);
				});
			
		},		
		
		
		addEmployeeDetails : function(employee,token){			
            return $http.post('http://localhost:8080/AmwayTest/api/employees/addemployees?access_token='+token,employee,{headers:{'Content-Type': 'application/json'}})
				.then(function(response){
					if (typeof response.data === 'object') {
                            return response.data;
                        } else {
                            // invalid response
                            return $q.reject(response.data);
                        }					
				},				
				function(response){					
					return $q.reject(response.data);
				});
			
		},
		
		login : function(user,password){			
			return $http.get('http://localhost:8080/AmwayTest/oauth/token?grant_type=password&client_id=new_client&client_secret=$2a$11$gxpnezmYfNJRYnw&username='+user+'&password='+password)
				.then(function(response){
					if (typeof response.data === 'object') {
                            return response.data;
                        } else {
                            // invalid response
                            return $q.reject(response.data);
                        }
					
				},				
				function(response){					
					return $q.reject(response.data);
				});
			
		},
		refreshToken : function(refresh_token){			
			return $http.get('http://localhost:8080/AmwayTest/oauth/token?grant_type=refresh_token&client_id=new_client&client_secret=$2a$11$gxpnezmYfNJRYnw&refresh_token='+refresh_token)
				.then(function(response){
					if (typeof response.data === 'object') {
                            return response.data;
                        } else {
                            // invalid response
                            return $q.reject(response.data);
                        }
					
				},				
				function(response){					
					return $q.reject(response.data);
				});
			
		},

        calculateDistance : function(origin,destination,token){	
           // console.log("5");
		return $http.get('http://localhost:8080/AmwayTest/api/employees/getdistance?access_token='+token+'&origins='+origin+'&destination='+destination)
				.then(function(response){
					if (typeof response.data === 'object') {
                        //console.log("6");
                            return response.data;
                        } else {
                            //console.log("7");
                            // invalid response
                            return $q.reject(response.data);
                        }
					
				},				
				function(response){	
                    //console.log("8");
					return $q.reject(response.data);
				});
			
		}
		
		
	};	
	
});