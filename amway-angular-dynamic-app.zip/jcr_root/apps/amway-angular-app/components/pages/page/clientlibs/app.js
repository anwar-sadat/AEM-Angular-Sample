var app = angular.module('amwayApp', ['ngRoute','ngCookies','ui.grid']);

app.controller('AppController', ['$scope', '$routeParams',
  function($scope, $routeParams) {
    
  }]);
  
app.controller('HomeCtrl', 
  function($scope,AmwayService,$cookies, $cookieStore) {
		$scope.anonymous = true;
		$scope.initHome = function()
		{
			if($cookies.get('access_token'))
					$scope.anonymous = false;
			else
					$scope.anonymous = true;
				
		}
		
		$scope.login = function(){
			 AmwayService.login($scope.username,$scope.password)
                    .then(function(data) {
                           if(data.access_token)
						   {
							   var expDate = new Date();
							   expDate.setSeconds(expDate.getSeconds()+data.expires_in);
							   $cookies.put('access_token', data.access_token,{'expires':expDate});
							   $cookies.put('token_expires', expDate,{'expires':expDate});
							   $cookies.put('refresh_token', data.refresh_token,{'expires':expDate});
							   $scope.anonymous = false;
						   }
                        },
                        function(error) {
                            

                        });
			
		}
  });
  
app.controller('DetailsCtrl', 
  function($scope,AmwayService, $routeParams,$location,$cookies) {
	  
	  $scope.initDetails = function()
		{
			//$scope.getEmployees();
			if(!$cookies.get('access_token'))
			{
				$location.path('/');
			}
			else{
				
				$scope.getEmployees();
			}
			
		};
		
		$scope.getEmployees = function()
		{
			var diff = Math.floor(((new Date($cookies.get('token_expires'))) - new Date())/1000);
			if(diff < 200)
			{
				AmwayService.refreshToken($cookies.get('refresh_token'))
				.then(function(data) {
						
						if(data.access_token)
						   {
							   var expDate = new Date();
							   expDate.setSeconds(expDate.getSeconds()+data.expires_in);
							   $cookies.put('access_token', data.access_token,{'expires':expDate});
							   $cookies.put('token_expires', expDate,{'expires':expDate});
							   $cookies.put('refresh_token', data.refresh_token,{'expires':expDate});
							   $scope.anonymous = false;
							   $scope.makeDataCall();
						   }
                           
                        },
                        function(error) {
                            

                        });
			}
			else
			{
				$scope.makeDataCall();
				
			}
			
		};
		
		$scope.makeDataCall = function()
		{
			 AmwayService.getEmployeeDetails($cookies.get('access_token'))
                    .then(function(data) {
						
						$scope.employees = data;
                           
                        },
                        function(error) {
                            

                        });
			
		}
		
		$scope.gridOptions = {
        enableSorting: true,
        columnDefs: [
			{ name:'EmployeeID', field: 'id',enableSorting: false },
          { name:'Name', field: 'name',enableSorting: false },
          { name:'DOB', field: 'dob' ,enableSorting: false},
          { name:'Country', field: 'country',enableSorting: false}
          
        ],
        data : 'employees'
      };
    
  });
  
app.controller('AddCtrl', 
  function($scope, $routeParams,AmwayService,$location,$cookies) {
	  $scope.employee = EMPLOYEE;
	  $scope.initAdd = function()
		{
			if(!$cookies.get('access_token'))
			{
				$location.path('/');
			}
			
		};
		$scope.addEmployee = function()
		{
			var diff = Math.floor(((new Date($cookies.get('token_expires'))) - new Date())/1000);
			if(diff < 200)
			{
				AmwayService.refreshToken($cookies.get('refresh_token'))
				.then(function(data) {
						
						if(data.access_token)
						   {
							   var expDate = new Date();
							   expDate.setSeconds(expDate.getSeconds()+data.expires_in);
							   $cookies.put('access_token', data.access_token,{'expires':expDate});
							   $cookies.put('token_expires', expDate,{'expires':expDate});
							   $cookies.put('refresh_token', data.refresh_token,{'expires':expDate});
							   $scope.anonymous = false;
							   $scope.makeDataCall();
						   }
                           
                        },
                        function(error) {
                            

                        });
			}
			else
			{
				$scope.makeDataCall();
				
			}
			
			
		};
		$scope.makeDataCall = function()
		{
			var newDate = new Date($scope.employee.dob);
			var newDateString = "";
			newDateString = (newDate.getFullYear())+'-'+(newDate.getMonth()+1)+'-'+(newDate.getDate());
			$scope.employee.dob = newDateString;
			AmwayService.addEmployeeDetails(angular.toJson($scope.employee),$cookies.get('access_token'))
                    .then(function(data) {
						
						alert("Employee Added successfully");
                        $scope.employee.name = "";
                         $scope.employee.dob="";
                         $scope.employee.country="";


                        },
                        function(error) {



                        });
			
		}
    
  });

app.config(['$routeProvider',
  function($routeProvider) {
    $routeProvider.
	when('/', {
        templateUrl: '/content/angular-dynamic-app/home.partial.html',
        controller: 'HomeCtrl'
      }).
      when('/details', {
        templateUrl: '/content/angular-dynamic-app/details.partial.html',
        controller: 'DetailsCtrl'
      }).
      when('/add', {
        templateUrl: '/content/angular-dynamic-app/add.partial.html',
        controller: 'AddCtrl'
      }).
      otherwise({
        redirectTo: '/'
		
      });
  }]);