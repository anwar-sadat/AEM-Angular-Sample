app.factory('AmwayService', function ($http, $q) {
	return {		
		getEmployeeDetails : function(token){			
            return $http.get('http://localhost:8080/AmwayTest/api/employees/getemployees?access_token='+token)
				.then(function(response){
					if (typeof response.data === 'object') {
                            return response.data;
                        } else {
                            // invalid response
                            return $q.reject(response.data);
                        }
					
				},				
				function(response){					
					return $q.reject(response.data);
				});
			
		},		
		
		
		addEmployeeDetails : function(employee,token){			
			return $http.post('http://localhost:8080/AmwayTest/api/employees/addemployees?access_token='+token,employee)
				.then(function(response){
					if (typeof response.data === 'object') {
                            return response.data;
                        } else {
                            // invalid response
                            return $q.reject(response.data);
                        }					
				},				
				function(response){					
					return $q.reject(response.data);
				});
			
		},
		
		login : function(user,password){			
			return $http.get('http://localhost:8080/AmwayTest/oauth/token?grant_type=password&client_id=new_client&client_secret=$2a$11$gxpnezmYfNJRYnw&username='+user+'&password='+password)
				.then(function(response){
					if (typeof response.data === 'object') {
                            return response.data;
                        } else {
                            // invalid response
                            return $q.reject(response.data);
                        }
					
				},				
				function(response){					
					return $q.reject(response.data);
				});
			
		},
		refreshToken : function(refresh_token){			
			return $http.get('http://localhost:8080/AmwayTest/oauth/token?grant_type=refresh_token&client_id=new_client&client_secret=$2a$11$gxpnezmYfNJRYnw&refresh_token='+refresh_token)
				.then(function(response){
					if (typeof response.data === 'object') {
                            return response.data;
                        } else {
                            // invalid response
                            return $q.reject(response.data);
                        }
					
				},				
				function(response){					
					return $q.reject(response.data);
				});
			
		}
		
		
	};	
	
});